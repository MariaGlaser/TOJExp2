%%% Create condition matrices for Experiment 2 (arithmetic + BL)
%----------------------------------------------------------------
% Maria Glaser

clear

%%% PREPARE MATERIAL AND FOLDERS---------------------------------------

% subnum = 10;  % default
subnum = input('Tasks for how many subjects (even number)? '); 
if mod(subnum,2)~= 0
    error('Subject number must be even.');
end

% Functions
functionfolder = 'Functions\';
addpath(functionfolder);

% Load parameters
[p] = param_Experiment2();

% Folder
conditionfolder = 'ConditionandTasklists\';
addpath(conditionfolder);

%--------------------------------------------------------------------------
%%%                     ARITHMETIC (carry vs noncarry)
%--------------------------------------------------------------------------


%%% CONDITION MATRIX---------------------------------------------------

% preallocate for speed
ExperimentalConditions = [];
ExampleConditions = [];

for subj = 1:subnum
    
    % Operation
    operationList = p.operationList;
    
    % Side
    sideList = p.sideList;
    
    % SOAs (List of SOAs in Frames)
    SOAList = p.SOAListSecs;
    
    % Delay (List of delays in Frames)
    delayList = p.delayListSecs;
    
    % Delay jitter (List of delay jitters in Frames)
    delayJitterList = p.delayJitterListSecs;
    
    % Make a condition matrix (creates 1,2x1,2,3etc matrix) (each column a factor, each line a trial)
    condMatBase = fullfact([numel(operationList) numel(sideList) numel(SOAList) numel(delayList) numel(delayJitterList)]);
    
    % Rename elements in condition matrix (1,2,3, etc. to proper SOAs & delays)
    condMatBase(:,1) = operationList(condMatBase(:,1));
    condMatBase(:,2) = sideList(condMatBase(:,2));
    condMatBase(:,3) = SOAList(condMatBase(:,3));
    condMatBase(:,4) = delayList(condMatBase(:,4));
    condMatBase(:,5) = delayJitterList(condMatBase(:,5));
    
    % Duplicate the condition matrix to get the full number of trials (=2x)
    condMat = repmat(condMatBase, p.trialsPerCondition, 1);
    
    % Get the size of the matrix
    [numTrials, ~] = size(condMat);
    
    % Shuffle the conditions
    shuffler = Shuffle(1:numTrials);
    condMatShuff = condMat(shuffler,:);
    
    
    
    %%% ADD TASK NUMBERS TO MATRIX (depending on operation and carry)------
    
    if mod(subj,2)~= 0 % odd subject number ==> carry
        % Create a new column with task number (1~ for addition tasks, 2~ for subtraction tasks)
        taskList(condMatShuff(:,1)==1) = p.taskno_add_carry;
        taskList(condMatShuff(:,1)==2) = p.taskno_sub_carry;
        condMatShuff=[condMatShuff taskList'];
        
    elseif mod(subj,2)== 0 % even subject number ==> noncarry
        taskList(condMatShuff(:,1)==1) = p.taskno_add_noncarry;
        taskList(condMatShuff(:,1)==2) = p.taskno_sub_noncarry;
        condMatShuff=[condMatShuff taskList'];
        
    end
    
    % Shuffle the conditions again
    shuffler = Shuffle(1:numTrials);
    condMatShuff = condMatShuff(shuffler,:);
    
    % Example matrix
    examplerows = randsample(length(condMatShuff), p.numPractisetrials);
    exampleMat = condMatShuff(examplerows,:);
    
    
    %%% ADD SUBJECT NUMBER VECTOR AND TRIAL NUMBER VECTOR----------------
    
    % experimental list
    t = 1:numTrials;
    sub_id_exp = ones(numTrials,1)*subj;
    condMatShuffsubj = [sub_id_exp t' condMatShuff];
    
    % example list
    u = 1:p.numPractisetrials;
    sub_id_Pract = ones(p.numPractisetrials,1)*subj;
    exampleMatsubj = [sub_id_Pract u' exampleMat];
    
    
    %%% PUT THEM ALL IN ONE LIST and SAVE THEM----------------------------
    
    % experimental list
    ExperimentalConditions = [ExperimentalConditions; condMatShuffsubj];
    dlmwrite([conditionfolder, 'ExperimentalConditionList_Arith_090618.txt'], ExperimentalConditions, 'delimiter','\t');
    
    % example list
    ExampleConditions = [ExampleConditions; exampleMatsubj];
    dlmwrite([conditionfolder, 'ExampleConditionList_Arith_090618.txt'], ExampleConditions, 'delimiter','\t');
    
end % of for loop

%--------------------------------------------------------------------------
%%%                     BASELINE
%--------------------------------------------------------------------------

%%% CONDITION MATRIX---------------------------------------------------

% preallocate for speed
ExperimentalConditions = [];
ExampleConditions = [];

for subj = 1:subnum
      
    % Side
    sideList = p.sideList;
    
    % SOAs (List of SOAs in Frames)
    SOAList = p.SOAListSecs;
    
    % Delay (List of delays in Frames)
    delayList = p.delayListSecs;
    
    % Delay jitter (List of delay jitters in Frames)
    delayJitterList = p.delayJitterListSecs;
    
    % Make a condition matrix (creates 1,2x1,2,3etc matrix) (each column a factor, each line a trial)
    condMatBase = fullfact([numel(sideList) numel(SOAList) numel(delayList) numel(delayJitterList)]);
    
    % Rename elements in condition matrix (1,2,3, etc. to proper SOAs & delays)
    condMatBase(:,1) = sideList(condMatBase(:,1));
    condMatBase(:,2) = SOAList(condMatBase(:,2));
    condMatBase(:,3) = delayList(condMatBase(:,3));
    condMatBase(:,4) = delayJitterList(condMatBase(:,4));
    
    % Duplicate the condition matrix to get the full number of trials (=2x)
    condMat = repmat(condMatBase, p.trialsPerCondition, 1);
    
    % Get the size of the matrix
    [numTrials, ~] = size(condMat);
    
    % Shuffle the conditions
    shuffler = Shuffle(1:numTrials);
    condMatShuff = condMat(shuffler,:);
    
    
    % Example matrix
    examplerows = randsample(length(condMatShuff), p.numPractisetrials);
    exampleMat = condMatShuff(examplerows,:);
    
    
    %%% ADD SUBJECT NUMBER VECTOR AND TRIAL NUMBER VECTOR----------------
    
    % experimental list
    t = 1:numTrials;
    sub_id_exp = ones(numTrials,1)*subj;
    condMatShuffsubj = [sub_id_exp t' condMatShuff];
    
    % example list
    u = 1:p.numPractisetrials;
    sub_id_Pract = ones(p.numPractisetrials,1)*subj;
    exampleMatsubj = [sub_id_Pract u' exampleMat];
    
    
    %%% PUT THEM ALL IN ONE LIST and SAVE THEM----------------------------
    
    % experimental list
    ExperimentalConditions = [ExperimentalConditions; condMatShuffsubj];
    dlmwrite([conditionfolder, 'ExperimentalConditionList_BL_090618.txt'], ExperimentalConditions, 'delimiter','\t');
    
    % example list
    ExampleConditions = [ExampleConditions; exampleMatsubj];
    dlmwrite([conditionfolder, 'ExampleConditionList_BL_090618.txt'], ExampleConditions, 'delimiter','\t');
    
end % of for loop
