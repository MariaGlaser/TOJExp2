Notes zum TOJ-Experiment mit den Faktoren Operation (Addition, Subtraktion, Baseline), Carry (Carry, Noncarry) & Delay (250, 500, 750):

* die Condition Lists für das Experiment werden vorab mit einem anderen Skript erstellt: "CreateConditionLists_010618"

* um das Experiment zu starten, müssen das "Exp2_TOJ_BL_07_12_18.m" und das "Exp2_TOJ_arith_16_08_18.m" Skript gestartet werden
* wahrscheinlich am wichtigsten für euch: "Exp2_TOJ_arith_16_08_18.m"
* Trial: Fixation, Aufgabenpräsentation auditiv (+ Fixation), variables Delay (Fixation), 
TOJ Stimulus 1, TOJ Stimulus 1 & 2 (until verbal response to TOJ), Fragezeichen (until verbal response)

* um die visuelle Stimuluspräsentation zu realisieren: Abschnitt "play operand 1, operator and 2" anpassen ( markiert mit "%EDIT for Casarotti")
* je nachdem ob verbale Antworten beibehalten werden sollen, können dann alle restlichen "PsychPortAudio" Elemente gelöscht werden oder nicht
* falls verbale Antworten beibehalten werden sollen: überprüft die Geräte(nummern) für Input und Output mit "devices = PsychPortAudio('GetDevices');"
* diese müssen dann im zweiten Argument des PsychportAudio('Open') Befehls definiert werden 
* edit, auf meinem privaten Laptop macht der PsychportAudio('Open') Befehl gerade auch Ärger egal welche Device ID ich angebe -> am besten erst einmal alle PsychportAudio Befehle kommentieren und dann laufen lassen
* außerdem muss das Skript auf einem 100 Hz Screen laufen, falls nicht, dann muss der entsprechende Check in line 92 gelöscht oder angepasst werden

