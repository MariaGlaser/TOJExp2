  %%%%%%%%%%%%%%%% Part I: TOJ_BaselineTask %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Maria Glaser
%%% dissertation project
%%% NOTE only space and escape keys allowed
%%% NOTE all times are logged in sec format

% for graphics issues put this in command line before experiment: opengl('save','software')
% [o] make sure: no other apps open, nor virus software, close previous workspace
Screen('Preference', 'SkipSyncTests', 1);

%%----------------------------------------------------------------------
%                   General setup
%%----------------------------------------------------------------------
% Clear Matlab/Octave window:
clc;

% Check for Opengl compatibility, abort otherwise:
AssertOpenGL;

% Reseed the random-number generator for each expt.
rng('shuffle');

%%----------------------------------------------------------------------
%                  Get Participant Information
%%----------------------------------------------------------------------
% Date info
t = datetime('now', 'Format', 'dd-MM-yyyy HH:mm'); % NOTE new psychtoolbox command, could cause error
date = datestr(t);

prompt = {'subject:', 'age:', 'gender: <f> or <m>', 'handedness: <l> or <r> or <na>'};
def = {'','','',''};
answer = inputdlg(prompt,'Setup Information', [1 45; 1 45; 1 45; 1 45], def);

% Now decode answer
subject_Number = str2double(answer{1});
subject_Age = str2double(answer{2});
subject_Gender = (answer{3});
subject_Handedness = (answer{4});

% Default input
% subject_Number = 99;
% subject_Age = 99;
% subject_Gender = 99;
% subject_Handedness = 99;

%%----------------------------------------------------------------------
%                  General Screen Settings
%%----------------------------------------------------------------------
% Here we call some default settings for setting up Psychtoolbox
PsychDefaultSetup(2); % NOTE new psychtoolbox command, could cause error

% Get the screen numbers for each screen attached to the computer
screens = Screen('Screens');

% Select the maximum of these numbers - we will draw to this screen
screenNumber = max(screens);

% Define white and grey
white = WhiteIndex(screenNumber);
grey = white / 2;

% Open an on screen window and color it grey
[window, windowRect] = PsychImaging('OpenWindow', screenNumber, grey);  % NOTE new psychtoolbox command, could cause error

% Do dummy calls
KbCheck;
WaitSecs(0.1);
GetSecs;

% Flip to clear
startexp = Screen('Flip', window);

% Retreive the maximum priority number
topPriorityLevel = MaxPriority(window);
Priority(topPriorityLevel);

% Get the size of the on screen window in pixels
[screenXpixels, screenYpixels] = Screen('WindowSize', window);

% Get the centre coordinate of the window in pixels
[xCenter, yCenter] = RectCenter(windowRect);

% Set the blend function for the screen
Screen('BlendFunction', window, 'GL_SRC_ALPHA', 'GL_ONE_MINUS_SRC_ALPHA');

%%----------------------------------------------------------------------
%                  Timing information
%%----------------------------------------------------------------------
% Query the frame duration
ifi = Screen('GetFlipInterval', window);

%error if ifi is <10 
% if ifi*1000<10 || ifi*1000>10.01
%     sca;
%     fclose('all');
%     ifi10 = ifi*1000;
%     error('Incorrect interframeinterval. Ifi was %.5f', ifi10);
% end

% Number of frames to wait when specifying good timing (we flip every frame)
waitframes = 1;

%%----------------------------------------------------------------------
%                  Sound information
%%----------------------------------------------------------------------
% Initialize Sounddriver
InitializePsychSound(1);
PsychPortAudio('Verbosity', 10);

%%----------------------------------------------------------------------
%                  Keyboard information
%%----------------------------------------------------------------------
% Keyboard setup (only space and escape keys allowed)
KbName('UnifyKeyNames');
space=KbName('space');
escape=KbName('escape');
Y=KbName('y');
N=KbName('n');
RestrictKeysForKbCheck([space escape Y N]);

%%----------------------------------------------------------------------
%                Define Folders & Load experimental parameters
%%----------------------------------------------------------------------
% main directory
experimentaldirectory = '';

% Instructions
instructionfolder = 'Instructions\';
addpath(instructionfolder);

% Functions
functionfolder = 'Functions\';
addpath(functionfolder);

% Condition Folder
conditionfolder = 'ConditionandTasklists\';
addpath(conditionfolder);

% Load parameters
[p] = param_Experiment2();
experimentname = p.experimentnameBL;

% Load numerical tasks & condition lists
prac_cond = dlmread('ExampleConditionList_BL_090618.txt');
exp_cond = dlmread('ExperimentalConditionList_BL_090618.txt');

% Result Folder
resultfolder = 'Results\';
addpath(resultfolder);

%%----------------------------------------------------------------------
%                  Result Folder and Result File
%%----------------------------------------------------------------------
% Create result folder
SJdatadir = [resultfolder, 'Data_', experimentname, '_SJ', int2str(subject_Number), '/'];

if subject_Number<99 && exist(SJdatadir, 'dir') >= 1 
    sca;
    fclose('all');
    error('Result data folder already exists. Choose a different subject number.');
elseif exist(SJdatadir, 'dir') < 1
    mkdir(SJdatadir);
end

% Define output
SJdatafile = [SJdatadir, 'Data_', experimentname, '_SJ', int2str(subject_Number), '.txt'];

% Check whether file already exists (then error), if not create & open it
% except when subject number is >=99 
if subject_Number<99 && fopen(SJdatafile, 'rt')~=-1
    fclose('all');
    error('Result data file already exists. Choose a different subject number.');
else
    datafilepointer = fopen(SJdatafile,'wt'); % open ASCII file for writing
end

% Format strings for title and data in result file
formatStringtitles = '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n'; % for titles
formatStringdata = '%d\t%d\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%s\n'; % for input

% Create titles in result file
fprintf(datafilepointer, formatStringtitles, ...
    'subject', ...
    'age', ...
    'gender', ...
    'handedness', ...
    'block', ...
    'trial', ...
    'operation', ...
    'side', ...
    'SOAframes', ...
    'delayframes', ...
    'delayjitterframes', ...
    'VOTtoj', ...
    'StartTrial_t', ...
    'StartFix_t', ...
    'Fix_dur', ...
    'StartDelaytoj_t', ...
    'Delaytoj_dur', ...
    'StartSquare1_t', ...
    'Square1_dur', ...
    'StartSquare2_t', ...
    'StarttojRec_t', ...
    'Responsetoj_t', ...
    'date-time', ...
    'experimentname');

%%----------------------------------------------------------------------
%                  Condition Matrix
%%----------------------------------------------------------------------
% get part of condition list that belongs to sepecific subject number
praccond_subj = prac_cond((prac_cond(:,1)==subject_Number),:);
expcond_subj = exp_cond((exp_cond(:,1)==subject_Number),:);

% convert time-dependent conditions in frames
praccond_subj(:,7) = round(praccond_subj(:,4) / ifi); % SOA
expcond_subj(:,7) = round(expcond_subj(:,4) / ifi);

praccond_subj(:,8) = round(praccond_subj(:,5) / ifi); % delay
expcond_subj(:,8) = round(expcond_subj(:,5) / ifi);

praccond_subj(:,9) = round(praccond_subj(:,6) / ifi); % delay jitter
expcond_subj(:,9) = round(expcond_subj(:,6) / ifi);

numTrials = length(expcond_subj);

%%----------------------------------------------------------------------
%                  Pre-experimental definitions
%%----------------------------------------------------------------------
% Make a rectangle of 100 by 100 pixels and define positions
baseRect = [0 0 75 75];

% Left square
squareXleftpos = screenXpixels * 0.38;
leftrect = CenterRectOnPointd(baseRect, squareXleftpos, yCenter);

% Right square
squareXrightpos = screenXpixels * 0.62;
rightrect = CenterRectOnPointd(baseRect, squareXrightpos, yCenter);

% Both squares
squareXpos = [screenXpixels * 0.38; screenXpixels * 0.62];
numSquares = length(squareXpos);

allRects = nan(4, 2);
for i = 1:numSquares
    allRects(:, i) = CenterRectOnPointd(baseRect, squareXpos(i), yCenter);
end

% Calculate fixation star frame length
fixLengthFrames = round(p.fixLengthSecs / ifi);

%%----------------------------------------------------------------------
%%                  Experiment
%%----------------------------------------------------------------------
try
    % Hide the mouse cursor:
    HideCursor;
    
    % Sync us and get a time stamp
    vbl = Screen('Flip', window);
    waitframes = 1;
    
    % open sound buffer
    pahandle = PsychPortAudio('Open', 8, 2, 0, p.freq, p.nrchannels); %EDIT for Casarotti
    
    starttime = GetSecs;
    
    %-------------------------------------------------------------------
    %              pre-experimental instructions
    %-------------------------------------------------------------------
    
    %------------------------Herzlich Willkommen------------------------
    
    Screen('TextFont',window, 'Helvetica');
    Screen('TextSize',window, 40);
    Screen('TextStyle', window, 1);
    DrawFormattedText(window, 'Herzlich Willkommen zu diesem Experiment', 'center', screenYpixels*0.40, white);
    Screen('TextSize',window, 25);
    DrawFormattedText(window, 'Dr�cken Sie die Leertaste, um fortzufahren.', 'center', screenYpixels*0.90, white);
    
    Screen('Flip',window);
    
    % wait for response & if escape then exit
    [~, keyCode] = KbWait([], 3);
    if keyCode(escape)==1
        PsychPortAudio('Close', pahandle);
        sca;
        ShowCursor;
        fclose('all');
        Priority(0);
        return;
    elseif keyCode(space)==0 && keyCode(escape)==0
        KbWait([], 3);
    end
    
    %------------------------ 1st instructions for experiment --------
    
    % Read some text file & draw text + bottom line (press space)
    Screen('TextSize', window, 30);
    [mytext] = instructions_txtfile('Exp1_TOJ_Instruktion 1.txt');
    DrawFormattedText(window, mytext, 'center', screenYpixels*0.30, white);
    Screen('TextSize',window, 25);
    DrawFormattedText(window, 'Dr�cken Sie die Leertaste, um fortzufahren.', 'center', screenYpixels*0.90, white);
    
    Screen('Flip',window);
    
    % wait for response & if escape then exit
    [~, keyCode] = KbWait([], 3);
    if keyCode(escape)==1
        PsychPortAudio('Close', pahandle);
        sca;
        ShowCursor;
        fclose('all');
        Priority(0);
        return;
    elseif keyCode(space)==0 && keyCode(escape)==0
        KbWait([], 3);
    end
    %------------------------ 2nd instructions for experiment--------
    
    % Read some text file & draw text + bottom line (press space)
    Screen('TextSize', window, 30);
    [mytext] = instructions_txtfile('Exp1_TOJ_Instruktion 2.txt');
    DrawFormattedText(window, mytext, 'center', screenYpixels*0.30, white);
    Screen('TextSize',window, 25);
    DrawFormattedText(window, 'Dr�cken Sie die Leertaste, um fortzufahren.', 'center', screenYpixels*0.90, white);
    
    Screen('Flip',window);
    
    % wait for response & if escape then exit
    [~, keyCode] = KbWait([], 3);
    if keyCode(escape)==1
        PsychPortAudio('Close', pahandle);
        sca;
        ShowCursor;
        fclose('all');
        Priority(0);
        return;
    elseif keyCode(space)==0 && keyCode(escape)==0
        KbWait([], 3);
    end
    %------------------------we start w/ some practise trials-----
    
    Screen('TextSize',window, 35);
    DrawFormattedText(window, 'Dann geht es jetzt los mit ein paar', 'center', screenYpixels*0.40, white);
    DrawFormattedText(window, '\n\n �bungsaufgaben', 'center', screenYpixels*0.40, white);
    Screen('TextSize',window, 25);
    DrawFormattedText(window, 'Dr�cken Sie die Leertaste, um zu starten.', 'center', screenYpixels*0.90, white);
    
    Screen('Flip',window);
    
    % wait for response & if escape then exit
    [~, keyCode] = KbWait([], 3);
    if keyCode(escape)==1
        PsychPortAudio('Close', pahandle);
        sca;
        ShowCursor;
        fclose('all');
        Priority(0);
        return;
    elseif keyCode(space)==0 && keyCode(escape)==0
        KbWait([], 3);
    end
    
    %-------------------------------------------------------------------
    %              practise & experimental loop
    %-------------------------------------------------------------------
    
    % two parts, one practise part (max 2 blocks), one experimental part 
       blo=1;
    
    while blo <= p.numBlocksBL+2
     block = blo;
        if block == 1 || block == 2% practise blocks
            %trialspan = 1:p.numExampletrialsBL;
            trialspan = (block-1)*p.numPractisetrials/p.numBlocksPractice+1:(block)*p.numPractisetrials/p.numBlocksPractice;
            Mat = praccond_subj;
        else
            trialspan = (block-3)*numTrials/p.numBlocksBL+1:(block-2)*numTrials/p.numBlocksBL;
            Mat = expcond_subj;
        end
        
        % preallocate sound buffer
        PsychPortAudio('GetAudioData', pahandle, 10);
        
        % ------------ TRIAL LOOP -----------------------------------------
        
        for trial = trialspan
            
            % Get the conditions
            theSide = Mat(trial, 3);
            theSOA = Mat(trial, 7);
            theDelay = Mat(trial, 8);
            theDelayJitter = Mat(trial, 9);
           
            %-------------grey screen before fixation dot--------------
            
            % Flip to the screen & get timestamp
            [~, StimulusOnsetTime] =  Screen('Flip', window);
            StartTrial_t = (StimulusOnsetTime - startexp);
            WaitSecs(0.5);
            
            %--------------show fixation dot ---------------------------
            
            % Flip to the screen & get timestamp
            Screen('DrawDots', window, [xCenter yCenter], 20, white, [], 3);
            [vbl, StimulusOnsetTime] = Screen('Flip', window, vbl + (waitframes - 0.5)*ifi);
            StartFix_t = (StimulusOnsetTime - startexp);
            
            for i = 1:(fixLengthFrames-1) % minus 1 because it was flipped before
                Screen('DrawDots', window, [xCenter yCenter], 20, white, [], 3);
                Screen('Flip', window, vbl + (waitframes - 0.5)*ifi);
            end
            
            %--------------grey screen (delay)----------------------------
            
            % Flip to the screen & get timestamp
            Screen('DrawDots', window, [xCenter yCenter], 20, white, [], 3);
            [~, StimulusOnsetTime] = Screen('Flip', window, vbl + (waitframes - 0.5)*ifi);
            StartDelaytoj_t = (StimulusOnsetTime - startexp);
            
            for i = 1:(theDelay+theDelayJitter-1)
                Screen('DrawDots', window, [xCenter yCenter], 20, white, [], 3);
                Screen('Flip', window, vbl + (waitframes - 0.5)*ifi);
            end
            
            %--------------show 1 square ---------------------------------
            
            % create it on the lefthand (-1) or the righthand (1) side
            
            if theSide == -1
                
                % Draw the rect to the screen
                Screen('FillRect', window, [0 0 0], leftrect);
                Screen('DrawDots', window, [xCenter yCenter], 20, white, [], 3);
                
                % Flip to the screen & get timestamp
                [vbl, StimulusOnsetTime]  = Screen('Flip', window, vbl + (waitframes - 0.5)*ifi);
                StartSquare1_t = (StimulusOnsetTime - startexp);
                
                for i = 1:(theSOA-1)
                    Screen('DrawDots', window, [xCenter yCenter], 20, white, [], 3);
                    Screen('FillRect', window, [0 0 0], leftrect);
                    Screen('Flip', window, vbl + (waitframes - 0.5)*ifi);
                end
                
            elseif theSide == 1
                
                % Draw the rect to the screen
                Screen('DrawDots', window, [xCenter yCenter], 20, white, [], 3);
                Screen('FillRect', window, [0 0 0], rightrect);
                
                % Flip to the screen & get timestamp
                [vbl, StimulusOnsetTime] = Screen('Flip', window, vbl + (waitframes - 0.5)*ifi);
                StartSquare1_t = (StimulusOnsetTime - startexp);
                
                for i = 1:(theSOA-1)
                    Screen('DrawDots', window, [xCenter yCenter], 20, white, [], 3);
                    Screen('FillRect', window, [0 0 0], rightrect);
                    Screen('Flip', window, vbl + (waitframes - 0.5)*ifi);
                end
                
            end
            
            %--------------show two squares ---------------------------------
            
            % Draw the rect to the screen
            Screen('DrawDots', window, [xCenter yCenter], 20, white, [], 3);
            Screen('FillRect', window, [0 0 0], allRects);
            
            % Flip to the screen & get timestamp
            [vbl, StimulusOnsetTime] = Screen('Flip', window, vbl + (waitframes - 0.5)*ifi);
            StartSquare2_t = (StimulusOnsetTime - startexp);
            
            
            %--------------get verbal response----------------------------
            
            [keyisdown, secs, keyCode] = KbCheck;
            % exit if escape
            if keyisdown == 1 && keyCode(escape)==1
                VOTtoj = 88888; % define early exit
                sca;
                ShowCursor;
                PsychPortAudio('Close', pahandle);
                fclose('all');
                Priority(0);
                return;
            end
            
            % Start recording
            startrec = PsychPortAudio('Start', pahandle, 0, 0, 1);
            StarttojRec_t = (startrec - startexp);
            
            audiodata = PsychPortAudio('GetAudioData', pahandle);
            recordedaudio = audiodata;
            
            % Get voice onset
            level = 0;
            % Repeat as long as below trigger-threshold
            while level < p.voicetrigger && GetSecs < (startrec+p.maxTOJSecs)
                % Fetch current audiodata:
                [audiodata, offset, ~, tCaptureStart] = PsychPortAudio('GetAudioData', pahandle);
                % Attach it to our full sound vector:
                recordedaudio = [recordedaudio audiodata]; %#ok<AGROW>
                if ~isempty(audiodata) % Compute maximum signal amplitude in this chunk of data
                    level = max(abs(audiodata(1,:)));
                end
                if level < p.voicetrigger % Below trigger-threshold?
                    WaitSecs(0.0001); % Wait for a millisecond before next scan
                end
            end
            
            resptime = GetSecs();
            Responsetoj_t = resptime - startexp; % time when loop is left (either voice onset or response time window exceded)
            
            
            % Wait before rec is stopped to record answer as well
            if level > p.voicetrigger && GetSecs < (startrec+p.maxTOJSecs)
                WaitSecs(p.waitTOJSecs);
                % Fetch audiodata and transpose it (from lines to columns) to be put in a audiofile
                audiodata = PsychPortAudio('GetAudioData', pahandle);
                recordedaudio = [recordedaudio audiodata]; %#ok<AGROW>
                w = 0; % subject not too slow
            elseif level < p.voicetrigger && GetSecs > (startrec+p.maxTOJSecs)
                % Fetch audiodata and transpose it (from lines to columns) to be put in a audiofile
                audiodata = PsychPortAudio('GetAudioData', pahandle);
                recordedaudio = [recordedaudio audiodata]; %#ok<AGROW>
                Screen('TextSize', window, 35);
                DrawFormattedText(window, 'Versuche bitte lauter oder schneller zu antworten', 'center', screenYpixels*0.5, white);
                Screen('Flip',window);
                WaitSecs(1.5);
                w = 1; % subject too slow
            end
            
            % Fetch audiodata and transpose it (from lines to columns) to be put in a audiofile
            audiodata = PsychPortAudio('GetAudioData', pahandle);
            recordedaudio = [recordedaudio audiodata]; %#ok<AGROW>
            
            % Stop recording
            PsychPortAudio('Stop', pahandle);
            
            % Perform a last fetch operation to get all remaining data from the capture engine:
            audiodata = PsychPortAudio('GetAudioData', pahandle);
            
            % Attach it to our full sound vector:
            recordedaudio = [recordedaudio audiodata]; %#ok<AGROW>
            
            % Save audio to wav file
            filename = [SJdatadir, 'Response_TOJBL_SJ', int2str(subject_Number), '_B', num2str(block), '_T', num2str(trial), '.wav'];
            audiowrite(filename, recordedaudio', p.freq);
            
            % Log VOT
            VOTtoj = (Responsetoj_t - StarttojRec_t);
            
            if w == 1 % if subject too slow
                VOTtoj = 99999;
            end
            
            
            %----------LOG INFO after each trial --------
            
            Fix_dur = (StartDelaytoj_t - StartFix_t)*1000;
            Delaytoj_dur = (StartSquare1_t - StartDelaytoj_t)*1000;
            Square1_dur = (StartSquare2_t - StartSquare1_t)*1000;
            
            fprintf(datafilepointer, formatStringdata, ...
                subject_Number, ...
                subject_Age, ...
                subject_Gender, ...
                subject_Handedness, ...
                block, ...
                trial, ...
                p.operationBL, ...
                theSide, ...
                theSOA,...
                theDelay, ...
                theDelayJitter, ...
                VOTtoj, ...
                StartTrial_t, ...
                StartFix_t, ...
                Fix_dur, ...
                StartDelaytoj_t, ...
                Delaytoj_dur, ...
                StartSquare1_t, ...
                Square1_dur, ...
                StartSquare2_t, ...
                StarttojRec_t, ...
                Responsetoj_t, ...
                date, ...
                experimentname);
            
            WaitSecs(0.1);
            
            %-------------------------------------------------------------------
            %              INBETWEEN blocks and END screen
            %-------------------------------------------------------------------
            
            if block == 1 && trial == trialspan(end)
                % Read some text file & draw text + bottom line (press space)
                Screen('TextSize', window, 30);
                [mytext] = instructions_txtfile('Exp1_TOJ_Frage.txt');
                DrawFormattedText(window, mytext, 'center', screenYpixels*0.25, white);
                Screen('TextSize', window, 25);
                DrawFormattedText(window, 'Dr�cken Sie die Leertaste, um zu starten.', 'center', screenYpixels*0.90, white);
                Screen('Flip',window);
                % wait for response & if escape then exit
                [~, keyCode] = KbWait([], 3);
                if keyCode(escape)==1
                    PsychPortAudio('Close', pahandle);
                    sca;
                    ShowCursor;
                    fclose('all');
                    Priority(0);
                    return;
                elseif keyCode(N)==1 && keyCode(escape)==0
                    blo=3;
                    Screen('TextSize', window, 30);
                    [mytext] = instructions_txtfile('Exp1_TOJ_Start.txt');
                    DrawFormattedText(window, mytext, 'center', screenYpixels*0.25, white);
                    Screen('TextSize', window, 25);
                    DrawFormattedText(window, 'Dr�cken Sie die Leertaste, um zu starten.', 'center', screenYpixels*0.90, white);
                    Screen('Flip',window);
                    [~, keyCode] = KbWait([], 3);
                    
                elseif keyCode(Y)==1 && keyCode(escape)==0
                    Screen('TextSize', window, 30);
                    DrawFormattedText(window, 'Alles klar. Dann folgen nun ein paar weitere �bungsdurchg�nge.', 'center', screenYpixels*0.45, white);
                    Screen('TextSize', window, 25);
                    DrawFormattedText(window, 'Dr�cken Sie die Leertaste, um zu starten.', 'center', screenYpixels*0.90, white);
                    Screen('Flip',window);
                    [~, keyCode] = KbWait([], 3);
                     blo=blo+1;
                end
                
            elseif block == 2 && trial == trialspan(end)
                Screen('TextSize', window, 30);
                [mytext] = instructions_txtfile('Exp1_TOJ_Start.txt');
                DrawFormattedText(window, mytext, 'center', screenYpixels*0.25, white);
                Screen('TextSize', window, 25);
                DrawFormattedText(window, 'Dr�cken Sie die Leertaste, um zu starten.', 'center', screenYpixels*0.90, white);
                Screen('Flip',window);
                [~, keyCode] = KbWait([], 3);
                 blo=blo+1;
                
            elseif block ~= 1 && block ~= p.numBlocksBL+2 && trial == trialspan(end)
                Screen('TextSize', window, 40);
                DrawFormattedText(window, 'Pause', 'center', screenYpixels*0.45, white);
                Screen('TextSize', window, 25);
                DrawFormattedText(window, 'Dr�cken Sie die Leertaste, um fortzufahren.', 'center', screenYpixels*0.90, white);
                t_pausestart = Screen('Flip',window);
                [~, keyCode] = KbWait([], 3);
                blo=blo+1;
                if keyCode(escape)==1
                    sca;
                    ShowCursor;
                    PsychPortAudio('Close');
                    fclose('all');
                    Priority(0);
                end
            elseif block == p.numBlocksBL+2 && trial == trialspan(end)
                Screen('TextSize', window, 30);
                [mytext] = instructions_txtfile('Exp1_TOJ_Ende.txt');
                DrawFormattedText(window, mytext, 'center', screenYpixels*0.40, white);
                Screen('Flip',window);
                % wait for keypress (escape or space)
                KbWait([], 3);
                blo=blo+1;
            end
            
        end % of trial loop
        
    end % of while loop
    
    % Close all
    PsychPortAudio('Close', pahandle);
    sca;
    ShowCursor;
    fclose('all');
    Priority(0);
    
catch
    % Close all
    PsychPortAudio('Close', pahandle);
    ShowCursor;
    Priority(0);
    fclose('all');
    sca;
    
    % the error message that describes the error:
    psychrethrow(psychlasterror);
    
end % try ... catch %