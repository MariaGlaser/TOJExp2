%%%%%%%%%%%%%%%% VOICE ONSET number word stimuli %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Maria Glaser
%%% dissertation project

%%% Experiment 1
%--------------------------------------------------------------------
clear

% main directory
experimentaldirectory = '';

% Load wav Stimuli
stimulifolder = 'Stimuli\';
addpath(stimulifolder);

% Load numerical tasks
taskdata = dlmread('Aufgaben_Experiment1.txt');
taskdatasubset = taskdata(:,2:3);
numbers = unique(taskdatasubset);

% define voicetrigger (values lie between -1 and 1) %% CAN BE CHANGED
voicetrigger = 0.008;

% preallocate for speed
timeinsecfirst = NaN;
timeinseclast = NaN;
duration = NaN;
idx = NaN;

for numberwordidx = 1:length(numbers)
    
    audiofile = [stimulifolder, int2str(numbers(numberwordidx)),'.wav'];
    audionumberword = transpose(audioread(audiofile));
    
    idx = audionumberword>voicetrigger;
    
%      %%% did not work properly!! (index was longer than audioanalogy)
%     for i=1:length(audionumberword)
%         if audionumberword(i)>voicetrigger
%             idx(i) = 1;
%         else
%             idx(i) = 0;
%         end
%     end

    
    %%% more complicated version
    %      % onset time
    %     v = zeros(1,6);
    %     v(:) = 1;
    %     v(1)= 0;
    %     firstoneindex = strfind(idx, v)+1;
    %     firstone = firstoneindex(1);
    %
    %     % offset time
    %     w = zeros(1,6);
    %     w(:) = 1;
    %     w(end) = 0;
    %     lastoneindex = strfind(idx, w)+4;
    %     lastone = lastoneindex(end);
    
    %%% simpler version
    firstone = find(idx,1,'first');
    lastone = find(idx,1,'last');
    
    timeinsecfirst(numberwordidx) = firstone/48000;
    timeinseclast(numberwordidx) = lastone/48000;
    
    duration(numberwordidx) = length(audionumberword)/48000;
end

% mean onset and offset times are given in seconds
Onset_mean = mean(timeinsecfirst);
Onset_sd = std(timeinsecfirst);

Offset_mean = mean(timeinseclast);
Offset_sd = std(timeinseclast);

duration_mean = mean(duration);
duration_sd = std(duration);

%%% Experiment 2
%--------------------------------------------------------------------
% Load wav Stimuli
Tasklistfolder = 'ConditionandTasklists\';
addpath(Tasklistfolder);

% Load numerical tasks
taskdata = dlmread('Tasklist_Experiment2_090618.txt');
taskdatasubset = taskdata(:,2:3);
numbers2 = unique(taskdatasubset);

% preallocate for speed
timeinsecfirst2 = NaN;
timeinseclast2 = NaN;
duration2 = NaN;
idx = NaN;

for numberwordidx2 = 1:length(numbers2)
    
    audiofile = [stimulifolder, int2str(numbers2(numberwordidx2)),'.wav'];
    audionumberword = transpose(audioread(audiofile));
    
    idx = audionumberword>voicetrigger;
    
%      %%% did not work properly!! (index was longer than audioanalogy)
%     for i=1:length(audionumberword)
%         if audionumberword(i)>voicetrigger
%             idx(i) = 1;
%         else
%             idx(i) = 0;
%         end
%     end
    
    %%% simpler version
    firstone = find(idx,1,'first');
    lastone = find(idx,1,'last');
    
    timeinsecfirst2(numberwordidx2) = firstone/48000;
    timeinseclast2(numberwordidx2) = lastone/48000;
    
    duration2(numberwordidx2) = length(audionumberword)/48000;
end

% mean onset and offset times are given in seconds
Onset2_mean = mean(timeinsecfirst2);
Onset2_sd = std(timeinsecfirst2);

Offset2_mean = mean(timeinseclast2);
Offset2_sd = std(timeinseclast2);

duration2_mean = mean(duration2);
duration2_sd = std(duration2);

%%% plus minus
%--------------------------------------------------------------------
operators = ['plus' 'minus'];
idx2 = NaN;
optimeinsecfirst = NaN;
optimeinseclast = NaN;
opduration = NaN;
voicetrigger = 0.01;

for j = 1:2
    
    if j == 1
        dummyOperator = 'plus';
    elseif j == 2
        dummyOperator = 'minus';
    end
    
    operator = [stimulifolder, dummyOperator, 'mono.wav'];
    audio = transpose(audioread(operator));
    
    for i=1:length(audio)
        
        if audio(i)>voicetrigger
            idx2(i) = 1;
        else
            idx2(i) = 0;
        end
    end
    
    opfirstone = find(idx2,1,'first');
    oplastone = find(idx2,1,'last');
    
    optimeinsecfirst(j) = opfirstone/48000;
    optimeinseclast(j) = oplastone/48000;
    
    opduration(j) = length(audio)/48000;
end

opduration_mean = mean(opduration);

