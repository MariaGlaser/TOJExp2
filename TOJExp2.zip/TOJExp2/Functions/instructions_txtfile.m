function [mytext] = instructions_txtfile(textfile)
% helpful script when loading instructions from textfile

% Read some text file:
fd = fopen(textfile, 'rt');
if fd==-1
    error('Could not open InstruktionTOJ file in PTB root folder!');
end
instruktion = fopen(textfile);         % �ffnen
mytext = fscanf(instruktion, '%c');

end

