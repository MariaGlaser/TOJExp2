function [p] = param_Experiment2( ~ )
% Experimental parameters used in the experimental scripts 
% (TOJ_BL & TOJ_Arith)
% Change parameters ONLY HERE

% define name of the experiment
p.experimentnameBL = ('Exp2_TOJ_BL');  
p.experimentnameArith = ('Exp2_TOJ_Arith');

% operation
p.operationBL = 0; % 0 = BL; 
p.operationList = [1 2]; % 1 = addition & 2 = subtraction

% carry
p.carryList = [0 1]; %0 = noncarry & 1 = carry

% Side
p.sideList = [-1 1]; % left (-1) and right (1)

% SOA between TOJ stimuli in seconds
p.SOAListSecs = [0.020 0.040 0.070 0.110]; 

% delay between TOJ and previous stimulus in seconds
p.delayListSecs = [0.250 0.750 1.500];

% delay jitter in seconds
p.delayJitterListSecs = [-0.080 -0.040 0.040 0.080];

% number vectors for arithmetic task numbers
p.taskno_add_carry = 11001:11192; 
p.taskno_sub_carry = 21001:21192;
p.taskno_add_noncarry = 10001:10192; 
p.taskno_sub_noncarry = 20001:20192;

% Number of Trials per condition 
p.trialsPerCondition = 2;

% number of example blocks and trials 
p.numBlocksPractice = 2;
p.numPractisetrials = 24;
% p.numExampletrialsBL = 24;
% p.numExampletrialsArith = 24;

% Number of experimental blocks (eventually +2 because first blocks are
% practise blocks)
p.numBlocksBL = 4;
p.numBlocksArith = 12;

% length fixation cross (in secs)
p.fixLengthSecs = 0.5;

% length fixed delay (before arith. task)
p.fixedDelay = 0.3; 

% verbal response maximums (in secs) 
p.maxTOJSecs = 2;
p.maxArithSecs = 7.5;

% wait for response to end (in secs)
p.waitTOJSecs = 1;
p.waitArithSecs = 2;

%-----------------------

% Sound settings
p.nrchannels = 2;
p.freq = 48000;
p.voicetrigger = 0.1;

silencesec = 0.5;
p.silence = zeros(1,p.freq*silencesec);

end

